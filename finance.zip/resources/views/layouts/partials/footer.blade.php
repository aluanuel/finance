<footer class="main-footer">
    <strong>&copy; {{date('Y') }} <a href="https://codestoreinvestments.com" target="blank">Codestore Investments Ltd</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>CSI Finance</b> 1.0.3
    </div>
  </footer>