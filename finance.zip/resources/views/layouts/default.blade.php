<!DOCTYPE html>
<html lang="en">
@include('layouts.partials.head')
<body class="hold-transition login-page">
	@yield('content')


@include('layouts.partials.footer-scripts')

</body>
</html>